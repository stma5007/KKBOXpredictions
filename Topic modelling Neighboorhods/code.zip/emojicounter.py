import emoji


with open("emojis.txt") as myfile:

    list_of_emojis = []
    natureemojis = [x.strip("\n").replace(' '' ', '') for x in myfile]
    for x in natureemojis:
        list_of_emojis.append(emoji.demojize(x))

with open("vesterbro.txt") as myfile:
    list_of_amager = []
    amager_emojis = [x.strip("\n").replace(' '' ', '') for x in myfile]
    for x in amager_emojis:
        list_of_amager.append(emoji.demojize(x))

"""with open("nørrebro.txt") as myfile:
    list_of_nb = []
    nb_emojis = [x.strip("\n").replace(' '' ', '') for x in myfile]
    for x in nb_emojis:
        list_of_nb.append(emoji.demojize(x))"""

counter = 0
for x in list_of_emojis:
    for y in list_of_amager:
        if x in y:
            counter +=1

print(counter)
